module.exports = {
    USER_ALREADY_REGISTERED:
      "You have already registerd with us please login to continue",
    SOMETHING_WENT_WRONG: "Something went wrong, please try after sometime",
    EMAIL_NOT_FOUND: "You Didn't register with us, please register first",
    PASSWORD_WRONG: "Please enter correct email and password",
    ADMIN_CANNOT_BE_REEGISTER: "admin can't be register here",
    UNAUTHORIZED: "Unauthorized Access",
    WRONG_OTP: "Please enter correct otp",
    MOBILE_NOT_FOUND: "Mobile Number not found",
    MOBILE_NOT_VERIFIED: "Please verify your mobile number before login",
    ENTER_CORRECT_USER_PASS: "Enter Correct email and password",
  };
  