let log4js = require('log4js');
let log = log4js.getLogger();
log.level = 'all';
module.exports = log;